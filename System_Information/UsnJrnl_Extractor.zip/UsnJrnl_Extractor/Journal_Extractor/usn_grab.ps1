﻿# Gets USN Journal
C:\Journal_Extractor\ExtractUsnJrnl.exe /DevicePath:c: /OutputPath:C:\Journal_Extractor | out-null

# Compresses file
makecab 'C:\Journal_Extractor\$UsnJrnl_$J.bin' C:\Journal_Extractor\$env:COMPUTERNAME-jrnl.cab | Out-Null
