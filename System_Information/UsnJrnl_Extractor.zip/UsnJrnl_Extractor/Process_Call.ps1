﻿<#
    .SYNOPSIS
        This script runs ExtractUsnJrnl.exe on a remote system or systems. After completion, it retrieves the results from the distant compter and 
        saves it to the local machine. Lastly, the copied script and output are deleted from the distant machine.

    .REQUIREMENTS
        - Requires an account on the remote computer
        - Requires C$ or Admin Share

    .REFERENCES
            https://github.com/jschicht/ExtractUsnJrnl
            https://github.com/jschicht/UsnJrnl2Csv
#>

# Reads in a list of computers that we will be running the script on
$computers = get-content C:\users\blue\Desktop\computers.txt

# Directory to pull results back to on the local machine
$results = ".\_Results"

foreach($computer in $computers)
    {
    # Deletes directory we are copying if it already exists on distant machine
    $distant_path = "\\$computer\c$\Journal_Extractor"
        if ($distant_path -ne $null)
            {
            Remove-Item $distant_path -recurse -force -ErrorAction SilentlyContinue
            }

    # Copies script to be ran on distant machine
    Copy-Item .\Journal_Extractor \\$computer\c$\. -Recurse

    # Creates variable for WMI process
    $Action = [wmiclass] "\\$computer\ROOT\CIMv2:Win32_Process"

    # Creates process creation to invoke the BlueSpectrum script that we copied.
    $Method = $Action.create("powershell /c c:\Journal_Extractor\usn_grab.ps1")

    write-host "Initiated process on $computer" -ForegroundColor Green
    }

# Allow time for the command to run
sleep 120

foreach($computer in $computers)
    {
    # Retrieves the results from the distant machine and saves it locally
    copy-Item \\$computer\c$\Journal_Extractor\*jrnl*.cab  $results\ 

    write-host "Pulling data back from $computer" -ForegroundColor Cyan

    # Deletes the directory on the distant machine
    remove-item \\$computer\c$\Journal_Extractor\ -Recurse -Force -ErrorAction SilentlyContinue
    remove-item \\$computer\c$\Journal_Extractor\ -Recurse -Force -ErrorAction SilentlyContinue
}

sleep 10

# Expand cab files
$cabs = Get-ChildItem $results | where{$_.Extension -eq ".cab"} | % { $_.fullname}
foreach($cab in $cabs)
    {
    write-host "Expanding data: $cab" -ForegroundColor yellow
    $temp = $cab.Replace(".cab",".bin")
    expand.exe $cab $temp | Out-Null
    }
