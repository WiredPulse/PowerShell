Requirements:
	v2 or newer
	WMI
	c$

Usage:
1) Download and uncompress the UsnJrnl_Extractor.zip file.
2) Verify that the following structure exists after unzipping.
	-> UsnJrnl_Extractor
		-> _Results
		-> Journal_Extractor
			-> ExtractUsnJrnl.exe
			-> Usn_grab.ps1
		-> UsnJrnl2CSV	
			-> Import-csv-usnjrnl.sql
			-> License.md
			-> UsnJrnl2csv.au3
			-> UsnJrnl2csv.exe	
			-> UsnJrnl2csv64.exe
			-> UsnJrnl-schema.sql
 		-> Process_Call.ps1
		-> Readme.txt

3) Open 'Process_Call.ps1' and adjust the $computers variable (line 16) to represent your environment.
4) Open an elevated PowerShell window and change directories to the UsnJrnl_Extractor directory.
5) From within the UsnJrnl_Extractor directory, execute 'Process_Call.ps1'
5) Once data is returned to the local machine in the _Results folder, run UsnJrnl2CSV against the .bin files captured.
     Example syntax:
	.\UsnJrnl2Csv\UsnJrnl2Csv.exe /UsnJrnlFile:\C:\users\<some folder>\UsnJrnl_Extractor\_results\<some file>.bin /OutputPath:\users\<some folder>\UsnJrnl_Extractor\_results

     Note: If the commandline way doesn't work, just call the \usnjrnl2csv.exe and use the GUI
6) Open the .csv produced in Excel. Be sure to set the time colun to "text". The times in the file are on UTC.